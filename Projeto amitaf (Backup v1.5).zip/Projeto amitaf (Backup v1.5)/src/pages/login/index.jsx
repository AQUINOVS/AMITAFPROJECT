import './index.css';

export default function App() {
    return (
        <div className="App">
            <div className=" login"> 
                <h2>Login</h2>
                <input type="text" placeholder="Username" />
                <input type="password" placeholder="password" />
                <input type="submit" value="Sign in" />
                <div className='grupo'>
                    <a href="#">esqueci minha senha</a>
                    <a href="#">inscrever-se</a>
                </div>
            </div>
        </div> 
    )

}
import './index.css';

export default function App() {
  return (
    <div className="Home">
      <header>
        <a className='amitaf' href=""><img src="/assets/images/Logo-Amitaf.png" alt="Logo amitaf" /></a>
      
      <nav>
        <a className='links' href="#principal">PRINCIPAL</a>
        <a className='links' href="#serviços">SERVIÇOS</a>
        <a className='links' href="#contato">CONTATO</a>
        <button className='links' href="#saibamais">SAIBA MAIS <i class="fa-solid fa-chevron-down fa-2xs"></i></button>  
      </nav>
      </header>

      <main>
        <img className='mulher' src="/assets/images/mulher.png" alt="" />

        <div className='imagens'>
        <img className='letreiro' src="/assets/images/letreiro.png" alt="" />
        <img className='amitaf' src="/assets/images/Logo-Amitaf.png" alt="" />
        </div>
      </main>

      <div className="transicao">
        <h1>Renove sua AUTOESTIMA com Amitaf</h1>
      </div>
    </div>
  ); 
} 
